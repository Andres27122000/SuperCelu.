package com.supercelu.app

import android.content.Context
import android.hardware.camera2.CameraCharacteristics
import android.hardware.camera2.CameraManager
import android.os.Handler
import android.os.Looper

/** Controla el flash del celular como linterna (no necesita permiso de cámara). */
class Torch(context: Context) {
    private val cm = context.getSystemService(Context.CAMERA_SERVICE) as CameraManager

    private val cameraId: String? = try {
        cm.cameraIdList.firstOrNull { id ->
            cm.getCameraCharacteristics(id).get(CameraCharacteristics.FLASH_INFO_AVAILABLE) == true
        }
    } catch (e: Exception) {
        null
    }

    var isOn = false
        private set

    private val callback = object : CameraManager.TorchCallback() {
        override fun onTorchModeChanged(id: String, enabled: Boolean) {
            if (id == cameraId) isOn = enabled
        }
    }

    init {
        try {
            cm.registerTorchCallback(callback, Handler(Looper.getMainLooper()))
        } catch (e: Exception) {
        }
    }

    val available: Boolean get() = cameraId != null

    fun set(on: Boolean): Boolean {
        val id = cameraId ?: return false
        return try {
            cm.setTorchMode(id, on)
            isOn = on
            true
        } catch (e: Exception) {
            false
        }
    }

    fun toggle(): Boolean = set(!isOn)

    fun release() {
        try {
            cm.unregisterTorchCallback(callback)
        } catch (e: Exception) {
        }
    }
}
