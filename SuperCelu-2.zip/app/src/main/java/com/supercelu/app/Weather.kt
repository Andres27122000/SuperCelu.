package com.supercelu.app

import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

data class WeatherData(
    val place: String,
    val lat: Double,
    val lon: Double,
    val elevation: Double,
    val temp: Double,
    val feels: Double,
    val humidity: Int,
    val precipNow: Double,
    val code: Int,
    val windNow: Double,
    val isDay: Boolean,
    val tMax: Double,
    val tMin: Double,
    val rainProb: Int,
    val uvMax: Double,
    val windMax: Double,
    val dayCode: Int
)

/** Clima gratis y sin clave desde Open-Meteo. */
object WeatherApi {

    private fun httpGet(url: String): String {
        val c = URL(url).openConnection() as HttpURLConnection
        c.connectTimeout = 12000
        c.readTimeout = 12000
        c.setRequestProperty("User-Agent", "SuperCelu/1.0 (Android)")
        try {
            if (c.responseCode !in 200..299) throw IOException("HTTP ${c.responseCode}")
            return c.inputStream.bufferedReader().use { it.readText() }
        } finally {
            c.disconnect()
        }
    }

    data class Place(val lat: Double, val lon: Double, val name: String)

    fun geocode(city: String): Place? {
        val q = URLEncoder.encode(city.trim(), "UTF-8")
        val j = JSONObject(
            httpGet("https://geocoding-api.open-meteo.com/v1/search?name=$q&count=1&language=es&format=json")
        )
        val arr = j.optJSONArray("results") ?: return null
        if (arr.length() == 0) return null
        val r = arr.getJSONObject(0)
        val name = listOf(r.optString("name"), r.optString("admin1"), r.optString("country"))
            .filter { it.isNotBlank() }
            .joinToString(", ")
        return Place(r.getDouble("latitude"), r.getDouble("longitude"), name)
    }

    fun fetchJson(lat: Double, lon: Double): String {
        val url = "https://api.open-meteo.com/v1/forecast?latitude=$lat&longitude=$lon" +
            "&current=temperature_2m,apparent_temperature,relative_humidity_2m,precipitation,weather_code,wind_speed_10m,is_day" +
            "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_probability_max,uv_index_max,wind_speed_10m_max" +
            "&timezone=auto&forecast_days=1"
        return httpGet(url)
    }

    private fun JSONArray.d0(): Double = optDouble(0, 0.0).let { if (it.isNaN()) 0.0 else it }
    private fun JSONObject.dbl(key: String): Double = optDouble(key, 0.0).let { if (it.isNaN()) 0.0 else it }

    fun parse(json: String, place: String): WeatherData {
        val j = JSONObject(json)
        val cur = j.getJSONObject("current")
        val d = j.getJSONObject("daily")
        return WeatherData(
            place = place,
            lat = j.dbl("latitude"),
            lon = j.dbl("longitude"),
            elevation = j.dbl("elevation"),
            temp = cur.dbl("temperature_2m"),
            feels = cur.dbl("apparent_temperature"),
            humidity = cur.dbl("relative_humidity_2m").toInt(),
            precipNow = cur.dbl("precipitation"),
            code = cur.optInt("weather_code", 0),
            windNow = cur.dbl("wind_speed_10m"),
            isDay = cur.optInt("is_day", 1) == 1,
            tMax = d.getJSONArray("temperature_2m_max").d0(),
            tMin = d.getJSONArray("temperature_2m_min").d0(),
            rainProb = d.getJSONArray("precipitation_probability_max").d0().toInt(),
            uvMax = d.getJSONArray("uv_index_max").d0(),
            windMax = d.getJSONArray("wind_speed_10m_max").d0(),
            dayCode = d.getJSONArray("weather_code").optInt(0, 0)
        )
    }
}
