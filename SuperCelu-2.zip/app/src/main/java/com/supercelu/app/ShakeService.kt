package com.supercelu.app

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Build
import android.os.IBinder
import android.os.SystemClock
import android.os.VibrationEffect
import android.os.Vibrator
import kotlin.math.sqrt

/** Servicio en segundo plano que escucha el acelerómetro y prende/apaga la linterna con 2 sacudidas. */
class ShakeService : Service(), SensorEventListener {

    private lateinit var sensorManager: SensorManager
    private lateinit var torch: Torch
    private var lastPeak = 0L
    private var firstPeak = 0L
    private var peaks = 0
    private var lastToggle = 0L

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
        torch = Torch(this)
        sensorManager = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        sensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)?.let {
            sensorManager.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME)
        }
        running = true
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int = START_STICKY

    @Suppress("DEPRECATION")
    private fun startAsForeground() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Linterna por sacudida", NotificationManager.IMPORTANCE_MIN)
            )
        }
        val pi = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val builder = if (Build.VERSION.SDK_INT >= 26) Notification.Builder(this, CHANNEL)
        else Notification.Builder(this)
        val n = builder
            .setSmallIcon(R.drawable.ic_flash)
            .setContentTitle("Linterna por sacudida activa")
            .setContentText("Sacudí el celu 2 veces para prender o apagar")
            .setContentIntent(pi)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIF_ID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(NOTIF_ID, n)
        }
    }

    override fun onSensorChanged(e: SensorEvent) {
        val x = e.values[0]
        val y = e.values[1]
        val z = e.values[2]
        val g = sqrt(x * x + y * y + z * z) / SensorManager.GRAVITY_EARTH
        if (g < Prefs.threshold(this)) return

        val now = SystemClock.elapsedRealtime()
        if (now - lastPeak < 300) return // es la misma sacudida
        lastPeak = now

        if (peaks == 0 || now - firstPeak > 1200) {
            peaks = 1
            firstPeak = now
        } else {
            peaks++
        }

        if (peaks >= 2 && now - lastToggle > 1500) {
            lastToggle = now
            peaks = 0
            if (torch.toggle()) vibrate()
        }
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    @Suppress("DEPRECATION")
    private fun vibrate() {
        val v = getSystemService(Context.VIBRATOR_SERVICE) as? Vibrator ?: return
        if (Build.VERSION.SDK_INT >= 26) {
            v.vibrate(VibrationEffect.createOneShot(60, VibrationEffect.DEFAULT_AMPLITUDE))
        } else {
            v.vibrate(60)
        }
    }

    override fun onDestroy() {
        running = false
        try {
            sensorManager.unregisterListener(this)
        } catch (e: Exception) {
        }
        torch.release()
        super.onDestroy()
    }

    companion object {
        private const val CHANNEL = "shake"
        private const val NOTIF_ID = 1

        @Volatile
        var running = false

        fun start(ctx: Context) {
            val i = Intent(ctx, ShakeService::class.java)
            try {
                if (Build.VERSION.SDK_INT >= 26) ctx.startForegroundService(i) else ctx.startService(i)
            } catch (e: Exception) {
            }
        }

        fun stop(ctx: Context) {
            ctx.stopService(Intent(ctx, ShakeService::class.java))
        }
    }
}
