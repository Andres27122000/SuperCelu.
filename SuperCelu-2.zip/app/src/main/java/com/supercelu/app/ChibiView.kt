package com.supercelu.app

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.Path
import android.graphics.RectF
import android.graphics.Shader
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View
import kotlin.math.cos
import kotlin.math.min
import kotlin.math.sin

/** Muñequito cabezón animado que se viste según el clima. */
class ChibiView @JvmOverloads constructor(
    ctx: Context,
    attrs: AttributeSet? = null
) : View(ctx, attrs) {

    private var outfit: Outfit? = null
    private var isDay = true

    private val p = Paint(Paint.ANTI_ALIAS_FLAG)
    private val st = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeCap = Paint.Cap.ROUND
        strokeJoin = Paint.Join.ROUND
    }
    private val txt = Paint(Paint.ANTI_ALIAS_FLAG).apply { textAlign = Paint.Align.CENTER }
    private val rect = RectF()
    private val path = Path()
    private val clip = Path()
    private val dp = resources.displayMetrics.density

    private val skin = col("#F5C9A0")
    private val hair = col("#4A3222")

    private fun col(s: String): Int = Color.parseColor(s)

    private fun darker(c: Int, f: Float = 0.78f): Int =
        Color.rgb((Color.red(c) * f).toInt(), (Color.green(c) * f).toInt(), (Color.blue(c) * f).toInt())

    private fun rr(l: Float, t: Float, r: Float, b: Float): RectF {
        rect.set(l, t, r, b); return rect
    }

    fun setOutfit(o: Outfit, day: Boolean) {
        outfit = o
        isDay = day
        invalidate()
    }

    override fun onDraw(c: Canvas) {
        super.onDraw(c)
        val w = width.toFloat()
        val h = height.toFloat()
        if (w <= 0f || h <= 0f) return
        val t = SystemClock.uptimeMillis()
        val o = outfit

        val radius = 18f * dp
        clip.reset()
        clip.addRoundRect(RectF(0f, 0f, w, h), radius, radius, Path.Direction.CW)
        c.save()
        c.clipPath(clip)

        drawSky(c, w, h, o?.sky ?: Sky.CLEAR, t)

        if (o == null) {
            txt.color = Color.WHITE
            txt.textSize = 16f * dp
            c.drawText("Cargando el clima…", w / 2f, h / 2f, txt)
        } else {
            // Área de dibujo del muñeco (coordenadas de diseño)
            val minX: Float; val maxX: Float; val minY: Float
            val maxY = 400f
            when {
                o.umbrella -> { minX = -20f; maxX = 360f; minY = -180f }
                o.hat == Hat.SUNHAT -> { minX = 10f; maxX = 290f; minY = 0f }
                else -> { minX = 40f; maxX = 260f; minY = 0f }
            }
            val s = min(w * 0.9f / (maxX - minX), h * 0.9f / (maxY - minY))
            val ox = w / 2f - (minX + maxX) / 2f * s
            val oy = h / 2f - (minY + maxY) / 2f * s
            val bob = sin(t / 450.0).toFloat() * 4f
            val shiver = if (o.mood == Mood.COLD) sin(t / 35.0).toFloat() * 1.6f else 0f

            c.save()
            c.translate(ox + shiver * s, oy + bob * s)
            c.scale(s, s)
            drawDoll(c, o, t)
            c.restore()

            drawFloating(c, o, w, h, t)
            if (o.mosquitoes) drawMosquitoes(c, w, h, t)
        }

        c.restore()
        postInvalidateOnAnimation()
    }

    // ===================== CIELO =====================
    private fun drawSky(c: Canvas, w: Float, h: Float, sky: Sky, t: Long) {
        val colors = when {
            !isDay -> "#1B2440" to "#3C4F7C"
            sky == Sky.CLEAR -> "#6EC6FF" to "#D9F1FF"
            sky == Sky.CLOUDY || sky == Sky.FOG -> "#9FB3C8" to "#E3EAF1"
            sky == Sky.SNOW -> "#B8C6D6" to "#F2F6FA"
            else -> "#5D6D7E" to "#A9B7C4"
        }
        p.shader = LinearGradient(0f, 0f, 0f, h, col(colors.first), col(colors.second), Shader.TileMode.CLAMP)
        c.drawRect(0f, 0f, w, h, p)
        p.shader = null

        // Sol o luna
        val sr = h * 0.07f
        val sx = w * 0.16f
        val sy = h * 0.15f
        if (isDay && (sky == Sky.CLEAR || sky == Sky.CLOUDY)) {
            st.color = col("#FFD54F")
            st.strokeWidth = 3f * dp
            val ang = t / 3000.0
            for (i in 0 until 10) {
                val a = ang + i * Math.PI / 5
                c.drawLine(
                    sx + (cos(a) * sr * 1.35).toFloat(), sy + (sin(a) * sr * 1.35).toFloat(),
                    sx + (cos(a) * sr * 1.75).toFloat(), sy + (sin(a) * sr * 1.75).toFloat(), st
                )
            }
            p.color = col("#FFC107")
            c.drawCircle(sx, sy, sr, p)
        } else if (!isDay) {
            p.color = col("#F5F3CE")
            c.drawCircle(sx, sy, sr, p)
            p.color = col("#DCD9AE")
            c.drawCircle(sx - sr * 0.3f, sy - sr * 0.2f, sr * 0.22f, p)
            c.drawCircle(sx + sr * 0.35f, sy + sr * 0.3f, sr * 0.15f, p)
            p.color = Color.WHITE
            for (i in 0 until 14) {
                val x = (i * 97 % 100) / 100f * w
                val y = (i * 53 % 45) / 100f * h
                val tw = ((sin(t / 400.0 + i) + 1) / 2).toFloat()
                p.alpha = (80 + tw * 175).toInt()
                c.drawCircle(x, y, 1.6f * dp, p)
            }
            p.alpha = 255
        }

        // Nubes
        if (sky != Sky.CLEAR || !isDay) {
            val n = if (sky == Sky.CLEAR) 1 else 3
            for (i in 0 until n) {
                val speed = 25f + i * 12f
                val span = w + 160f * dp
                val x = ((t / 1000f * speed * dp + i * span / n) % span) - 80f * dp
                val y = h * (0.12f + i * 0.09f)
                val gray = sky == Sky.RAIN || sky == Sky.STORM
                p.color = if (gray) col("#CC78909C") else col("#E6FFFFFF")
                drawCloud(c, x, y, 34f * dp)
            }
        }

        // Lluvia
        if (sky == Sky.RAIN || sky == Sky.STORM) {
            st.color = col("#AAE3F2FD")
            st.strokeWidth = 2f * dp
            for (i in 0 until 45) {
                val x = (i * 73 % 100) / 100f * w
                val y = ((t * 0.9f + i * 137f) % (h + 40f)) - 20f
                c.drawLine(x, y, x - 4f * dp, y + 14f * dp, st)
            }
            if (sky == Sky.STORM && (t / 90) % 40 == 0L) {
                p.color = col("#88FFFFFF")
                c.drawRect(0f, 0f, w, h, p)
            }
        }

        // Nieve
        if (sky == Sky.SNOW) {
            p.color = Color.WHITE
            for (i in 0 until 40) {
                val x = (i * 61 % 100) / 100f * w + sin(t / 700.0 + i).toFloat() * 8f * dp
                val y = ((t * 0.08f + i * 97f) % (h + 20f)) - 10f
                c.drawCircle(x, y, 2.5f * dp, p)
            }
        }

        // Niebla
        if (sky == Sky.FOG) {
            p.color = col("#55FFFFFF")
            for (i in 0 until 4) {
                val y = h * (0.3f + i * 0.17f)
                val dx = sin(t / 2000.0 + i).toFloat() * 20f * dp
                c.drawRoundRect(rr(-40f + dx, y, w + 40f + dx, y + 22f * dp), 11f * dp, 11f * dp, p)
            }
        }

        // Pasto
        p.color = if (isDay) col("#8BC34A") else col("#3E5B2A")
        c.drawRect(0f, h * 0.86f, w, h, p)
    }

    private fun drawCloud(c: Canvas, x: Float, y: Float, r: Float) {
        c.drawCircle(x, y, r, p)
        c.drawCircle(x + r * 0.9f, y + r * 0.2f, r * 0.8f, p)
        c.drawCircle(x - r * 0.9f, y + r * 0.25f, r * 0.7f, p)
        c.drawRoundRect(rr(x - r * 1.5f, y + r * 0.1f, x + r * 1.6f, y + r * 0.95f), r * 0.4f, r * 0.4f, p)
    }

    // ===================== MUÑECO =====================
    private val ink = col("#1A1A1A")
    private val hairC = col("#1C1C24")
    private val hairHi = col("#454C66")
    private val ol = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE
        strokeWidth = 4.5f
        strokeJoin = Paint.Join.ROUND
        strokeCap = Paint.Cap.ROUND
    }

    private fun outline(c: Canvas, draw: (Paint) -> Unit, color: Int) {
        p.color = color
        draw(p)
        ol.color = ink
        draw(ol)
    }

    private fun rrO(c: Canvas, l: Float, t: Float, r: Float, b: Float, rad: Float, color: Int) {
        val rf = RectF(l, t, r, b)
        outline(c, { pt -> c.drawRoundRect(rf, rad, rad, pt) }, color)
    }

    private fun ovO(c: Canvas, l: Float, t: Float, r: Float, b: Float, color: Int) {
        val rf = RectF(l, t, r, b)
        outline(c, { pt -> c.drawOval(rf, pt) }, color)
    }

    private fun ciO(c: Canvas, x: Float, y: Float, rad: Float, color: Int) {
        outline(c, { pt -> c.drawCircle(x, y, rad, pt) }, color)
    }

    private fun pathO(c: Canvas, pa: Path, color: Int) {
        outline(c, { pt -> c.drawPath(pa, pt) }, color)
    }

    /** Brazo o pierna como trazo grueso con contorno. */
    private fun limb(c: Canvas, w: Float, color: Int, vararg pts: Float) {
        path.reset()
        path.moveTo(pts[0], pts[1])
        var i = 2
        while (i < pts.size) {
            path.lineTo(pts[i], pts[i + 1]); i += 2
        }
        st.color = ink; st.strokeWidth = w + 9f
        c.drawPath(path, st)
        st.color = color; st.strokeWidth = w
        c.drawPath(path, st)
    }

    private fun line(c: Canvas, x1: Float, y1: Float, x2: Float, y2: Float, color: Int, w: Float) {
        st.color = color; st.strokeWidth = w
        c.drawLine(x1, y1, x2, y2, st)
    }

    private fun curve(c: Canvas, x1: Float, y1: Float, cx: Float, cy: Float, x2: Float, y2: Float, color: Int, w: Float) {
        val pa = Path()
        pa.moveTo(x1, y1); pa.quadTo(cx, cy, x2, y2)
        st.color = color; st.strokeWidth = w
        c.drawPath(pa, st)
    }

    private fun drawDoll(c: Canvas, o: Outfit, t: Long) {
        // Sombra
        p.color = col("#33000000")
        c.drawOval(rr(86f, 374f, 214f, 396f), p)

        // ---------- Piernas, pantalón y calzado ----------
        if (o.shorts) {
            rrO(c, 124f, 300f, 145f, 372f, 10f, skin)
            rrO(c, 155f, 300f, 176f, 372f, 10f, skin)
            rrO(c, 114f, 282f, 186f, 328f, 12f, col("#455A64"))
            line(c, 150f, 300f, 150f, 326f, ink, 3f)
        } else {
            val pants = col("#1F1F1F")
            rrO(c, 118f, 280f, 149f, 370f, 10f, pants)
            rrO(c, 151f, 280f, 182f, 370f, 10f, pants)
            p.color = pants
            c.drawRect(121f, 282f, 179f, 310f, p)
            line(c, 150f, 312f, 150f, 368f, ink, 3f)
        }
        if (o.boots) {
            rrO(c, 111f, 344f, 149f, 386f, 10f, col("#F9A825"))
            rrO(c, 151f, 344f, 189f, 386f, 10f, col("#F9A825"))
        } else {
            ovO(c, 104f, 362f, 148f, 388f, col("#141414"))
            ovO(c, 152f, 362f, 196f, 388f, col("#141414"))
            curve(c, 114f, 370f, 122f, 366f, 130f, 368f, col("#88FFFFFF"), 3f)
            curve(c, 162f, 370f, 170f, 366f, 178f, 368f, col("#88FFFFFF"), 3f)
        }

        // ---------- Colores de la ropa ----------
        val topColor = if (o.raincoat) col("#FFD600") else when (o.top) {
            Top.TSHIRT -> col("#E64A19")
            Top.LONGSLEEVE -> col("#262626")
            Top.SWEATER -> col("#607D8B")
            Top.JACKET -> col("#1E1E1E")
            Top.COAT -> col("#8D6E63")
        }
        val long = o.top == Top.COAT || o.raincoat
        val torsoBottom = if (long) 334f else 300f
        val torsoL = if (long) 94f else 102f
        val torsoR = 300f - torsoL
        val fullSleeve = o.top != Top.TSHIRT || o.raincoat
        val handColor = if (o.gloves) col("#C62828") else skin

        // ---------- Brazos (detrás del torso) ----------
        // Brazo izquierdo levantado, con la mano en la cabeza
        if (fullSleeve) {
            limb(c, 24f, topColor, 110f, 224f, 64f, 252f, 90f, 172f)
        } else {
            limb(c, 20f, skin, 110f, 224f, 64f, 252f, 90f, 172f)
            limb(c, 26f, topColor, 110f, 224f, 82f, 240f)
        }
        // Brazo derecho: en el bolsillo, o sosteniendo el paraguas
        if (o.umbrella) {
            if (fullSleeve) limb(c, 24f, topColor, 190f, 224f, 214f, 262f, 211f, 290f)
            else {
                limb(c, 20f, skin, 190f, 224f, 214f, 262f, 211f, 290f)
                limb(c, 26f, topColor, 190f, 224f, 206f, 248f)
            }
        } else {
            if (fullSleeve) limb(c, 24f, topColor, 190f, 224f, 228f, 258f, 198f, 286f)
            else {
                limb(c, 20f, skin, 190f, 224f, 228f, 258f, 198f, 286f)
                limb(c, 26f, topColor, 190f, 224f, 212f, 240f)
            }
        }

        // ---------- Torso ----------
        rrO(c, torsoL, 204f, torsoR, torsoBottom, 26f, topColor)
        val shirt = col("#2E2E2E")
        val dark = darker(topColor, 0.6f)
        when {
            o.raincoat -> {
                line(c, 150f, 210f, 150f, torsoBottom - 6f, ink, 3.5f)
                p.color = dark
                c.drawCircle(140f, 244f, 4.5f, p); c.drawCircle(140f, 276f, 4.5f, p); c.drawCircle(140f, 308f, 4.5f, p)
            }
            o.top == Top.JACKET || o.top == Top.COAT -> {
                // Camisa en V + solapas, como en la imagen
                val v = Path()
                v.moveTo(128f, 205f); v.lineTo(150f, 264f); v.lineTo(172f, 205f); v.close()
                pathO(c, v, shirt)
                line(c, 150f, 222f, 150f, 258f, col("#555555"), 2f)
                val lapL = Path()
                lapL.moveTo(126f, 205f); lapL.lineTo(114f, 236f); lapL.lineTo(136f, 246f); lapL.lineTo(150f, 268f)
                st.color = ink; st.strokeWidth = 3.5f; c.drawPath(lapL, st)
                val lapR = Path()
                lapR.moveTo(174f, 205f); lapR.lineTo(186f, 236f); lapR.lineTo(164f, 246f); lapR.lineTo(150f, 268f)
                c.drawPath(lapR, st)
                p.color = col("#3A3A3A")
                c.drawCircle(150f, 278f, 4.5f, p)
                if (long) { c.drawCircle(150f, 298f, 4.5f, p); c.drawCircle(150f, 318f, 4.5f, p) }
                line(c, 168f, 262f, 188f, 262f, ink, 3f)
            }
            o.top == Top.LONGSLEEVE -> {
                val cl = Path()
                cl.moveTo(132f, 204f); cl.lineTo(150f, 222f); cl.lineTo(140f, 230f); cl.close()
                pathO(c, cl, topColor)
                val cr = Path()
                cr.moveTo(168f, 204f); cr.lineTo(150f, 222f); cr.lineTo(160f, 230f); cr.close()
                pathO(c, cr, topColor)
                line(c, 150f, 222f, 150f, 296f, ink, 2.5f)
                p.color = col("#5A5A5A")
                for (y in listOf(236f, 254f, 272f, 290f)) c.drawCircle(150f, y, 3.5f, p)
            }
            o.top == Top.SWEATER -> {
                st.color = dark; st.strokeWidth = 5f
                c.drawLine(torsoL + 10f, 244f, torsoR - 10f, 244f, st)
                c.drawLine(torsoL + 10f, 268f, torsoR - 10f, 268f, st)
                curve(c, 132f, 206f, 150f, 222f, 168f, 206f, ink, 3.5f)
            }
            else -> {
                curve(c, 134f, 206f, 150f, 220f, 166f, 206f, ink, 3.5f)
                p.color = col("#FFE0B2")
                drawStar(c, 150f, 252f, 13f)
            }
        }

        // Cuello
        p.color = skin
        c.drawRect(140f, 190f, 160f, 208f, p)

        // Bufanda
        if (o.scarf) {
            rrO(c, 106f, 194f, 194f, 222f, 13f, col("#E53935"))
            rrO(c, 164f, 210f, 186f, 266f, 9f, col("#E53935"))
            line(c, 168f, 242f, 182f, 242f, col("#FFCDD2"), 4f)
            line(c, 168f, 254f, 182f, 254f, col("#FFCDD2"), 4f)
        }

        // ---------- Cabeza ----------
        // Pelo de atrás, en punta
        val back = Path()
        back.moveTo(54f, 150f)
        back.quadTo(40f, 96f, 70f, 62f)
        back.lineTo(50f, 44f)
        back.quadTo(90f, 34f, 108f, 24f)
        back.lineTo(110f, 2f)
        back.quadTo(140f, 10f, 160f, 12f)
        back.lineTo(182f, 0f)
        back.quadTo(204f, 18f, 216f, 32f)
        back.lineTo(244f, 26f)
        back.quadTo(254f, 60f, 254f, 92f)
        back.lineTo(266f, 104f)
        back.quadTo(258f, 132f, 248f, 152f)
        back.close()
        if (o.hat == Hat.NONE || o.hat == Hat.SUNHAT) pathO(c, back, hairC)

        // Orejas
        ciO(c, 62f, 144f, 15f, skin)
        ciO(c, 238f, 144f, 15f, skin)
        curve(c, 58f, 136f, 66f, 144f, 60f, 152f, col("#D9A07A"), 3f)
        curve(c, 242f, 136f, 234f, 144f, 240f, 152f, col("#D9A07A"), 3f)

        // Cara
        ciO(c, 150f, 128f, 88f, skin)

        // Flequillo con el mechón sobre la frente
        if (o.hat == Hat.NONE || o.hat == Hat.SUNHAT) {
            val f = Path()
            f.moveTo(60f, 132f)
            f.quadTo(56f, 70f, 112f, 48f)
            f.quadTo(172f, 30f, 226f, 62f)
            f.quadTo(252f, 86f, 242f, 130f)
            f.quadTo(232f, 108f, 214f, 96f)
            f.quadTo(202f, 104f, 190f, 90f)
            f.quadTo(160f, 86f, 136f, 98f)
            f.quadTo(116f, 108f, 104f, 128f)
            f.quadTo(104f, 106f, 92f, 100f)
            f.quadTo(80f, 112f, 72f, 134f)
            f.close()
            pathO(c, f, hairC)
            curve(c, 116f, 62f, 140f, 50f, 166f, 50f, hairHi, 5f)
            curve(c, 182f, 54f, 204f, 60f, 218f, 74f, hairHi, 4f)
            curve(c, 128f, 96f, 140f, 86f, 158f, 84f, hairHi, 3f)
        }

        // Cejas gruesas
        curve(c, 102f, 114f, 118f, 102f, 134f, 112f, ink, 8f)
        curve(c, 166f, 112f, 182f, 102f, 198f, 114f, ink, 8f)

        // Ojos
        when (o.mood) {
            Mood.HAPPY, Mood.HOT -> {
                curve(c, 104f, 144f, 118f, 128f, 132f, 144f, ink, 6f)
                curve(c, 168f, 144f, 182f, 128f, 196f, 144f, ink, 6f)
            }
            Mood.COLD -> {
                st.color = ink; st.strokeWidth = 6f
                val e = Path()
                e.moveTo(106f, 132f); e.lineTo(128f, 140f); e.lineTo(106f, 148f)
                e.moveTo(194f, 132f); e.lineTo(172f, 140f); e.lineTo(194f, 148f)
                c.drawPath(e, st)
            }
            Mood.WET -> {
                if ((t % 4200) < 130) {
                    line(c, 108f, 140f, 130f, 140f, ink, 5f)
                    line(c, 170f, 140f, 192f, 140f, ink, 5f)
                } else {
                    p.color = ink
                    c.drawOval(rr(110f, 126f, 128f, 152f), p)
                    c.drawOval(rr(172f, 126f, 190f, 152f), p)
                    p.color = Color.WHITE
                    c.drawCircle(123f, 133f, 4f, p); c.drawCircle(185f, 133f, 4f, p)
                }
            }
        }

        // Cachetes sonrojados con rayitas
        p.color = if (o.mood == Mood.COLD) col("#664FC3F7") else col("#73FF8A80")
        c.drawOval(rr(90f, 154f, 122f, 172f), p)
        c.drawOval(rr(178f, 154f, 210f, 172f), p)
        val bl = if (o.mood == Mood.COLD) col("#4FA3D1") else col("#E57373")
        for (k in 0 until 3) {
            line(c, 98f + k * 7f, 166f, 102f + k * 7f, 158f, bl, 2f)
            line(c, 186f + k * 7f, 166f, 190f + k * 7f, 158f, bl, 2f)
        }

        // Nariz
        curve(c, 146f, 152f, 150f, 157f, 154f, 153f, col("#B97A57"), 3f)

        // Boca
        when (o.mood) {
            Mood.HAPPY -> {
                curve(c, 134f, 168f, 152f, 182f, 170f, 164f, ink, 4.5f)
                line(c, 170f, 164f, 173f, 160f, ink, 4f)
            }
            Mood.HOT -> {
                val m = Path()
                m.moveTo(136f, 166f); m.quadTo(150f, 190f, 166f, 166f); m.close()
                pathO(c, m, col("#B23B3B"))
                p.color = col("#64B5F6")
                val dy = ((t / 15) % 30).toFloat()
                val d = Path()
                d.moveTo(228f, 80f + dy)
                d.quadTo(242f, 102f + dy, 228f, 106f + dy)
                d.quadTo(214f, 102f + dy, 228f, 80f + dy)
                d.close()
                c.drawPath(d, p)
            }
            Mood.COLD -> {
                st.color = ink; st.strokeWidth = 4.5f
                val m = Path()
                m.moveTo(134f, 170f); m.lineTo(143f, 163f); m.lineTo(152f, 170f); m.lineTo(161f, 163f); m.lineTo(170f, 170f)
                c.drawPath(m, st)
            }
            Mood.WET -> ovO(c, 144f, 162f, 158f, 178f, col("#8D3B2B"))
        }

        // Mano izquierda apoyada en la cabeza
        ciO(c, 90f, 170f, 14f, handColor)
        curve(c, 84f, 162f, 90f, 158f, 96f, 162f, col("#D9A07A"), 2.5f)
        // Mano derecha (solo si sostiene el paraguas)
        if (o.umbrella) ciO(c, 211f, 296f, 13f, handColor)

        // Anteojos de sol
        if (o.sunglasses) {
            rrO(c, 98f, 122f, 140f, 152f, 12f, col("#212121"))
            rrO(c, 160f, 122f, 202f, 152f, 12f, col("#212121"))
            line(c, 140f, 132f, 160f, 132f, col("#212121"), 5f)
            line(c, 98f, 132f, 66f, 128f, col("#212121"), 5f)
            line(c, 202f, 132f, 234f, 128f, col("#212121"), 5f)
            p.color = col("#55FFFFFF")
            c.drawRoundRect(rr(104f, 126f, 116f, 136f), 4f, 4f, p)
            c.drawRoundRect(rr(166f, 126f, 178f, 136f), 4f, 4f, p)
        }

        // Sombreros
        when (o.hat) {
            Hat.BEANIE -> {
                val bp = Path()
                bp.addArc(RectF(54f, 4f, 246f, 198f), 180f, 180f)
                bp.close()
                pathO(c, bp, col("#1E88E5"))
                rrO(c, 50f, 84f, 250f, 110f, 13f, col("#1565C0"))
                ciO(c, 150f, 8f, 16f, Color.WHITE)
            }
            Hat.CAP -> {
                val cp = Path()
                cp.addArc(RectF(58f, 10f, 242f, 194f), 180f, 180f)
                cp.close()
                pathO(c, cp, col("#E53935"))
                rrO(c, 150f, 92f, 274f, 110f, 9f, col("#B71C1C"))
                ciO(c, 150f, 12f, 6f, col("#B71C1C"))
            }
            Hat.SUNHAT -> {
                ovO(c, 16f, 72f, 284f, 116f, col("#E9C46A"))
                val sp = Path()
                sp.addArc(RectF(74f, 6f, 226f, 166f), 180f, 180f)
                sp.close()
                pathO(c, sp, col("#E9C46A"))
                p.color = col("#E57373")
                c.drawRect(78f, 68f, 222f, 84f, p)
            }
            Hat.NONE -> {}
        }

        // Paraguas
        if (o.umbrella) {
            line(c, 211f, 300f, 236f, -40f, col("#424242"), 6f)
            val rc = RectF(116f, -160f, 356f, 80f)
            val cols = intArrayOf(col("#7E57C2"), col("#B39DDB"))
            for (i in 0 until 4) {
                p.color = cols[i % 2]
                c.drawArc(rc, 180f + i * 45f, 45f, true, p)
            }
            ol.color = ink
            c.drawArc(rc, 180f, 180f, true, ol)
            line(c, 236f, -160f, 236f, -176f, col("#424242"), 6f)
        }
    }

    private fun drawStar(c: Canvas, cx: Float, cy: Float, r: Float) {
        path.reset()
        for (i in 0 until 10) {
            val rad = if (i % 2 == 0) r else r * 0.45f
            val a = -Math.PI / 2 + i * Math.PI / 5
            val x = cx + (cos(a) * rad).toFloat()
            val y = cy + (sin(a) * rad).toFloat()
            if (i == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }
        path.close()
        c.drawPath(path, p)
    }

    // ===================== OBJETOS FLOTANTES =====================
    private fun drawFloating(c: Canvas, o: Outfit, w: Float, h: Float, t: Long) {
        if (o.floating.isEmpty()) return
        txt.textSize = 28f * dp
        txt.color = Color.BLACK
        o.floating.forEachIndexed { i, e ->
            val x = w * 0.1f
            val y = h * 0.42f + i * 40f * dp + sin(t / 500.0 + i * 1.3).toFloat() * 5f * dp
            c.drawText(e, x, y, txt)
        }
    }

    private fun drawMosquitoes(c: Canvas, w: Float, h: Float, t: Long) {
        txt.textSize = 16f * dp
        for (i in 0 until 3) {
            val x = w * 0.82f + cos(t / 300.0 + i * 2.1).toFloat() * w * 0.08f
            val y = h * 0.42f + sin(t / 170.0 + i * 1.7).toFloat() * h * 0.1f
            c.drawText("🦟", x, y, txt)
        }
    }
}
