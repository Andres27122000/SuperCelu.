package com.supercelu.app

import kotlin.math.roundToInt

enum class Top { TSHIRT, LONGSLEEVE, SWEATER, JACKET, COAT }
enum class Hat { NONE, CAP, SUNHAT, BEANIE }
enum class Mood { HAPPY, HOT, COLD, WET }
enum class Sky { CLEAR, CLOUDY, RAIN, STORM, SNOW, FOG }

/** Lo que el muñeco tiene puesto y lo que conviene llevar. */
class Outfit {
    var top = Top.TSHIRT
    var shorts = false
    var hat = Hat.NONE
    var umbrella = false
    var raincoat = false
    var sunglasses = false
    var scarf = false
    var gloves = false
    var boots = false
    var mosquitoes = false
    var mood = Mood.HAPPY
    var sky = Sky.CLEAR
    var season = ""
    val items = mutableListOf<String>()
    val tips = mutableListOf<String>()
    val floating = mutableListOf<String>()
}

/** Reglas que deciden la ropa, los objetos y los consejos de salud según clima y temporada. */
object Advisor {

    fun season(lat: Double, month: Int): String {
        val m = if (lat < 0) (month + 6 - 1) % 12 + 1 else month
        return when (m) {
            12, 1, 2 -> "Invierno"
            3, 4, 5 -> "Primavera"
            6, 7, 8 -> "Verano"
            else -> "Otoño"
        }
    }

    fun describe(code: Int): String = when (code) {
        0 -> "Despejado"
        1 -> "Mayormente despejado"
        2 -> "Parcialmente nublado"
        3 -> "Nublado"
        45, 48 -> "Niebla"
        in 51..57 -> "Llovizna"
        in 61..67 -> "Lluvia"
        in 71..77 -> "Nieve"
        in 80..82 -> "Chaparrones"
        85, 86 -> "Nevadas"
        in 95..99 -> "Tormenta eléctrica"
        else -> "—"
    }

    fun sky(code: Int): Sky = when (code) {
        0, 1 -> Sky.CLEAR
        2, 3 -> Sky.CLOUDY
        45, 48 -> Sky.FOG
        in 51..67, in 80..82 -> Sky.RAIN
        in 71..77, 85, 86 -> Sky.SNOW
        in 95..99 -> Sky.STORM
        else -> Sky.CLOUDY
    }

    private fun uvLevel(uv: Double): String = when {
        uv >= 11 -> "extremo"
        uv >= 8 -> "muy alto"
        uv >= 6 -> "alto"
        uv >= 3 -> "moderado"
        else -> "bajo"
    }

    private fun r(v: Double): Int = v.roundToInt()

    fun advise(w: WeatherData, month: Int): Outfit {
        val o = Outfit()
        o.sky = sky(w.code)
        o.season = season(w.lat, month)
        val t = w.feels

        // ---------- ROPA según sensación térmica ----------
        when {
            t >= 26 -> { o.top = Top.TSHIRT; o.shorts = true }
            t >= 21 -> o.top = Top.TSHIRT
            t >= 16 -> o.top = Top.LONGSLEEVE
            t >= 11 -> o.top = Top.SWEATER
            t >= 4 -> o.top = Top.JACKET
            else -> o.top = Top.COAT
        }
        if (t < 8) { o.hat = Hat.BEANIE; o.scarf = true }
        if (t < 3) o.gloves = true
        o.mood = when {
            t >= 30 -> Mood.HOT
            t < 6 -> Mood.COLD
            else -> Mood.HAPPY
        }

        o.items.add(
            when (o.top) {
                Top.TSHIRT -> "👕 Remera"
                Top.LONGSLEEVE -> "👚 Manga larga"
                Top.SWEATER -> "🧶 Buzo o suéter"
                Top.JACKET -> "🧥 Campera"
                Top.COAT -> "🧥 Abrigo grueso"
            }
        )
        o.items.add(if (o.shorts) "🩳 Short o bermuda" else "👖 Pantalón largo")
        if (o.hat == Hat.BEANIE) o.items.add("❄️ Gorro de lana")
        if (o.scarf) o.items.add("🧣 Bufanda")
        if (o.gloves) o.items.add("🧤 Guantes")

        // ---------- LLUVIA ----------
        val rainingNow = w.precipNow > 0.1 || o.sky == Sky.RAIN || o.sky == Sky.STORM
        val daySky = sky(w.dayCode)
        val rainLikely = w.rainProb >= 50 || daySky == Sky.RAIN || daySky == Sky.STORM
        if (rainingNow || rainLikely) {
            if (w.windMax >= 35) {
                o.raincoat = true
                o.items.add("🧥 Piloto o impermeable (mucho viento para paraguas)")
            } else {
                o.umbrella = true
                o.items.add("☂️ Paraguas")
            }
            if (rainingNow && o.mood == Mood.HAPPY) o.mood = Mood.WET
            if (w.code in setOf(63, 65, 67, 81, 82, 95, 96, 99) || w.dayCode in setOf(65, 82, 99)) {
                o.boots = true
                o.items.add("🥾 Calzado que no se moje")
            }
            o.tips.add("🌧️ Probabilidad de lluvia del ${w.rainProb}%. Cuidado con charcos y calles resbalosas.")
        } else if (w.rainProb >= 30) {
            o.tips.add("🌦️ Puede caer algún chaparrón (${w.rainProb}%): un paraguas chico en la mochila no está de más.")
        }

        // ---------- SOL / UV ----------
        if (w.uvMax >= 3 && o.sky != Sky.STORM) {
            o.items.add("🧴 Protector solar")
            o.floating.add("🧴")
        }
        if (w.uvMax >= 6) {
            o.sunglasses = true
            o.items.add("🕶️ Anteojos de sol")
            if (o.hat == Hat.NONE) {
                if (w.uvMax >= 8) {
                    o.hat = Hat.SUNHAT
                    o.items.add("👒 Sombrero de ala ancha")
                } else {
                    o.hat = Hat.CAP
                    o.items.add("🧢 Gorra")
                }
            }
            o.tips.add("☀️ Índice UV ${r(w.uvMax)} (${uvLevel(w.uvMax)}): evitá el sol directo de 11 a 16 h y renová el protector cada 2 horas.")
        }

        // ---------- CALOR / AGUA ----------
        if (w.tMax >= 28) {
            o.items.add("💧 Botella de agua")
            o.floating.add("💧")
        }
        if (w.tMax >= 32) {
            o.tips.add("🥵 Riesgo de golpe de calor: tomá agua aunque no tengas sed y buscá sombra.")
            o.tips.add("🍗 Con este calor la comida se echa a perder rápido: no dejes alimentos fuera de la heladera.")
        }

        // ---------- AMPLITUD TÉRMICA ----------
        val amp = w.tMax - w.tMin
        if (amp >= 13) {
            o.tips.add("🌡️ Mucha diferencia entre día y noche (${r(w.tMin)}° a ${r(w.tMax)}°): vestite en capas.")
            if (w.tMin < 14 && (o.top == Top.TSHIRT || o.top == Top.LONGSLEEVE)) {
                o.items.add("🧥 Abrigo liviano para la noche")
                o.floating.add("🧥")
            }
        }

        // ---------- VIENTO / NIEBLA / TORMENTA ----------
        if (w.windMax >= 40) {
            o.tips.add("💨 Viento fuerte (hasta ${r(w.windMax)} km/h): rompeviento y cuidado con el polvo en los ojos.")
        }
        if (o.sky == Sky.FOG) {
            o.tips.add("🌫️ Niebla: si manejás, luces bajas y más distancia con el de adelante.")
        }
        if (o.sky == Sky.STORM || daySky == Sky.STORM) {
            o.tips.add("⛈️ Tormenta eléctrica: no te quedes al aire libre ni bajo árboles; desenchufá equipos sensibles.")
        }

        // ---------- ALTURA ----------
        if (w.elevation >= 2500) {
            o.tips.add("⛰️ Estás a ${r(w.elevation)} m de altura: el sol quema más, el aire es seco y las noches son frías. Tomá agua seguido.")
        }

        // ---------- TEMPORADA: INSECTOS Y ENFERMEDADES ----------
        val warmSeason = o.season != "Invierno"
        if (((warmSeason && w.tMax >= 22) || w.tMax >= 26) && w.elevation < 2200) {
            o.mosquitoes = true
            o.items.add("🦟 Repelente")
            o.tips.add("🦟 Época de mosquitos (dengue, chikungunya, zika): repelente, mangas largas al atardecer y vaciá todo recipiente con agua estancada.")
            if (rainingNow || rainLikely) {
                o.tips.add("🪣 Después de la lluvia revisá baldes, macetas y cubiertas: ahí se crían los mosquitos.")
            }
        }
        val inAmericas = w.lon in -120.0..-30.0 && w.lat in -45.0..40.0
        if (inAmericas && (o.season == "Primavera" || o.season == "Verano") && w.elevation < 3500) {
            o.tips.add("🪳 Temporada de vinchucas (Chagas), sobre todo en zonas rurales: revisá grietas, techos y debajo de las camas.")
        }
        if (o.season == "Primavera") {
            o.tips.add("🌼 Primavera: mucho polen. Si sos alérgico, anteojos afuera y lavate la cara al volver.")
        }
        if (o.season == "Invierno" || w.tMax < 14) {
            o.tips.add("🤧 Época de gripe y resfríos: lavado de manos, ventilá los ambientes y abrigate al salir de lugares cálidos.")
        }
        if (o.season == "Verano" && w.humidity >= 70 && w.tMax >= 28) {
            o.tips.add("🥤 Calor húmedo: transpirás más de lo que creés, sumá agua y frutas.")
        }

        return o
    }
}
