package com.supercelu.app

import android.Manifest
import android.annotation.SuppressLint
import android.app.Activity
import android.content.pm.PackageManager
import android.location.Geocoder
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.Button
import android.widget.EditText
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import kotlin.concurrent.thread
import kotlin.math.roundToInt

class MainActivity : Activity() {

    private lateinit var chibi: ChibiView
    private lateinit var tvPlace: TextView
    private lateinit var tvTemp: TextView
    private lateinit var tvDetails: TextView
    private lateinit var tvItems: TextView
    private lateinit var tvTips: TextView
    private lateinit var tvStatus: TextView
    private lateinit var etCity: EditText

    private var torch: Torch? = null
    private val main = Handler(Looper.getMainLooper())
    private var activeListener: LocationListener? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        chibi = findViewById(R.id.chibi)
        tvPlace = findViewById(R.id.tvPlace)
        tvTemp = findViewById(R.id.tvTemp)
        tvDetails = findViewById(R.id.tvDetails)
        tvItems = findViewById(R.id.tvItems)
        tvTips = findViewById(R.id.tvTips)
        tvStatus = findViewById(R.id.tvStatus)
        etCity = findViewById(R.id.etCity)

        setupFlashlight()

        findViewById<Button>(R.id.btnCity).setOnClickListener { searchCity() }
        etCity.setOnEditorActionListener { _, actionId, _ ->
            if (actionId == EditorInfo.IME_ACTION_DONE || actionId == EditorInfo.IME_ACTION_SEARCH ||
                actionId == EditorInfo.IME_ACTION_GO
            ) {
                searchCity(); true
            } else false
        }
        findViewById<Button>(R.id.btnLocation).setOnClickListener {
            Prefs.setLastCity(this, null)
            requestLocation()
        }

        // Mostrar el último clima guardado mientras se actualiza
        Prefs.cachedJson(this)?.let { json ->
            try {
                show(WeatherApi.parse(json, Prefs.cachedPlace(this)))
                status("Mostrando datos guardados, actualizando…")
            } catch (e: Exception) {
            }
        }

        val city = Prefs.lastCity(this)
        if (city != null) loadByCity(city) else requestLocation()
    }

    // ===================== LINTERNA =====================
    private fun setupFlashlight() {
        torch = Torch(this)
        val sw = findViewById<Switch>(R.id.swShake)
        val sb = findViewById<SeekBar>(R.id.sbSens)

        sw.isChecked = Prefs.shakeEnabled(this)
        if (Prefs.shakeEnabled(this) && !ShakeService.running) ShakeService.start(this)

        sw.setOnCheckedChangeListener { _, on ->
            Prefs.setShakeEnabled(this, on)
            if (on) {
                askNotificationPermission()
                ShakeService.start(this)
                toast("Listo: sacudí el celu 2 veces seguidas")
            } else {
                ShakeService.stop(this)
            }
        }

        sb.progress = Prefs.sensitivity(this)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar?, progress: Int, fromUser: Boolean) {
                if (fromUser) Prefs.setSensitivity(this@MainActivity, progress)
            }

            override fun onStartTrackingTouch(seekBar: SeekBar?) {}
            override fun onStopTrackingTouch(seekBar: SeekBar?) {}
        })

        findViewById<Button>(R.id.btnTorch).setOnClickListener {
            val t = torch
            if (t == null || !t.available) toast("Este celular no tiene flash")
            else if (!t.toggle()) toast("No se pudo usar el flash (¿lo está usando la cámara?)")
        }
    }

    private fun askNotificationPermission() {
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED
        ) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), REQ_NOTIF)
        }
    }

    // ===================== UBICACIÓN =====================
    private fun hasLocationPermission(): Boolean =
        checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED

    private fun requestLocation() {
        if (hasLocationPermission()) getLocation()
        else requestPermissions(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION), REQ_LOC)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == REQ_LOC) {
            if (grantResults.isNotEmpty() && grantResults[0] == PackageManager.PERMISSION_GRANTED) getLocation()
            else status("Sin permiso de ubicación: escribí tu ciudad arriba y tocá Buscar.")
        }
    }

    @SuppressLint("MissingPermission")
    private fun getLocation() {
        val lm = getSystemService(LOCATION_SERVICE) as LocationManager
        status("Buscando tu ubicación…")

        val providers = lm.getProviders(true)
        var best: Location? = null
        for (prov in providers) {
            val l = try {
                lm.getLastKnownLocation(prov)
            } catch (e: Exception) {
                null
            }
            if (l != null && (best == null || l.time > best.time)) best = l
        }
        val fallback = best
        if (fallback != null && System.currentTimeMillis() - fallback.time < 3 * 3600_000L) {
            loadByCoords(fallback.latitude, fallback.longitude)
            return
        }

        val provider = when {
            LocationManager.NETWORK_PROVIDER in providers -> LocationManager.NETWORK_PROVIDER
            LocationManager.GPS_PROVIDER in providers -> LocationManager.GPS_PROVIDER
            else -> null
        }
        if (provider == null) {
            if (fallback != null) loadByCoords(fallback.latitude, fallback.longitude)
            else status("Activá la ubicación del celu o escribí tu ciudad.")
            return
        }

        var got = false
        val listener = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                if (got) return
                got = true
                lm.removeUpdates(this)
                loadByCoords(location.latitude, location.longitude)
            }

            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}

            @Deprecated("Requerido en Android viejos")
            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {
            }
        }
        activeListener?.let { lm.removeUpdates(it) }
        activeListener = listener
        try {
            lm.requestLocationUpdates(provider, 0L, 0f, listener, Looper.getMainLooper())
        } catch (e: Exception) {
            status("No pude pedir la ubicación: escribí tu ciudad.")
            return
        }
        main.postDelayed({
            if (!got) {
                got = true
                lm.removeUpdates(listener)
                if (fallback != null) loadByCoords(fallback.latitude, fallback.longitude)
                else status("No encontré tu ubicación: escribí tu ciudad y tocá Buscar.")
            }
        }, 20_000L)
    }

    // ===================== CLIMA =====================
    private fun searchCity() {
        val c = etCity.text.toString().trim()
        if (c.isEmpty()) return
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager)
            .hideSoftInputFromWindow(etCity.windowToken, 0)
        loadByCity(c)
    }

    private fun loadByCity(city: String) {
        status("Buscando $city…")
        thread {
            try {
                val place = WeatherApi.geocode(city)
                if (place == null) {
                    runOnUiThread { status("No encontré \"$city\". Probá con otro nombre.") }
                    return@thread
                }
                Prefs.setLastCity(this, city)
                fetchAndShow(place.lat, place.lon, place.name)
            } catch (e: Exception) {
                runOnUiThread { status("Sin conexión o error al buscar la ciudad.") }
            }
        }
    }

    private fun loadByCoords(lat: Double, lon: Double) {
        status("Consultando el clima…")
        thread {
            try {
                fetchAndShow(lat, lon, placeName(lat, lon))
            } catch (e: Exception) {
                runOnUiThread { status("Sin conexión. Probá de nuevo en un rato.") }
            }
        }
    }

    @Suppress("DEPRECATION")
    private fun placeName(lat: Double, lon: Double): String {
        return try {
            val list = Geocoder(this, Locale("es")).getFromLocation(lat, lon, 1)
            val a = list?.firstOrNull()
            listOfNotNull(a?.locality ?: a?.subAdminArea, a?.countryName)
                .joinToString(", ")
                .ifBlank { "Tu ubicación" }
        } catch (e: Exception) {
            "Tu ubicación"
        }
    }

    /** Se llama desde un hilo en segundo plano. */
    private fun fetchAndShow(lat: Double, lon: Double, place: String) {
        val json = WeatherApi.fetchJson(lat, lon)
        val data = WeatherApi.parse(json, place)
        Prefs.cache(this, json, place)
        runOnUiThread {
            show(data)
            val hora = SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date())
            status("Actualizado a las $hora")
        }
    }

    private fun show(w: WeatherData) {
        val month = Calendar.getInstance().get(Calendar.MONTH) + 1
        val o = Advisor.advise(w, month)
        chibi.setOutfit(o, w.isDay)

        tvPlace.text = "${w.place} · ${o.season}"
        tvTemp.text = "${w.temp.roundToInt()}°C"
        tvDetails.text = "${Advisor.describe(w.code)} · Sensación ${w.feels.roundToInt()}°\n" +
            "Máx ${w.tMax.roundToInt()}° / Mín ${w.tMin.roundToInt()}° · Lluvia ${w.rainProb}%\n" +
            "UV ${w.uvMax.roundToInt()} · Viento ${w.windNow.roundToInt()} km/h · Humedad ${w.humidity}%"
        tvItems.text = o.items.joinToString("\n")
        tvTips.text = if (o.tips.isEmpty()) "😊 Día tranquilo, ¡disfrutalo!" else o.tips.joinToString("\n\n")
    }

    private fun status(s: String) {
        tvStatus.text = s
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    override fun onDestroy() {
        activeListener?.let {
            try {
                (getSystemService(LOCATION_SERVICE) as LocationManager).removeUpdates(it)
            } catch (e: Exception) {
            }
        }
        main.removeCallbacksAndMessages(null)
        torch?.release()
        super.onDestroy()
    }

    companion object {
        private const val REQ_LOC = 10
        private const val REQ_NOTIF = 11
    }
}
