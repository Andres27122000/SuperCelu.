package com.supercelu.app

import android.content.Context
import android.content.SharedPreferences

object Prefs {
    private fun p(c: Context): SharedPreferences =
        c.getSharedPreferences("supercelu", Context.MODE_PRIVATE)

    fun shakeEnabled(c: Context): Boolean = p(c).getBoolean("shake", false)
    fun setShakeEnabled(c: Context, v: Boolean) = p(c).edit().putBoolean("shake", v).apply()

    fun sensitivity(c: Context): Int = p(c).getInt("sens", 50)
    fun setSensitivity(c: Context, v: Int) = p(c).edit().putInt("sens", v).apply()

    /** Fuerza (en "g") necesaria para contar una sacudida: 3.6g (poco sensible) a 1.6g (muy sensible). */
    fun threshold(c: Context): Float = 3.6f - sensitivity(c) / 100f * 2.0f

    fun lastCity(c: Context): String? = p(c).getString("city", null)
    fun setLastCity(c: Context, v: String?) = p(c).edit().putString("city", v).apply()

    fun cachedJson(c: Context): String? = p(c).getString("json", null)
    fun cachedPlace(c: Context): String = p(c).getString("place", "Tu zona") ?: "Tu zona"
    fun cache(c: Context, json: String, place: String) =
        p(c).edit().putString("json", json).putString("place", place).apply()
}
