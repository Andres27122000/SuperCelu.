package com.supercelu.app

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent

/** Vuelve a activar la linterna por sacudida cuando se reinicia el celular. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action == Intent.ACTION_BOOT_COMPLETED && Prefs.shakeEnabled(context)) {
            ShakeService.start(context)
        }
    }
}
